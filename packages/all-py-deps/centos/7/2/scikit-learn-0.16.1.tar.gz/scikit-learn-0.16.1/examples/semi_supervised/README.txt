.. _semi_supervised_examples:

Semi Supervised Classification
------------------------------

Examples concerning the :mod:`sklearn.semi_supervised` module.
