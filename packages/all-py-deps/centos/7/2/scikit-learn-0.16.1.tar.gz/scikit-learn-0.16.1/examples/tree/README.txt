.. _tree_examples:

Decision Trees
--------------

Examples concerning the :mod:`sklearn.tree` module.
